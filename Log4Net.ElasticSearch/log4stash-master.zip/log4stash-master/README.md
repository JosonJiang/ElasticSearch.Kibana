# log4stash
修改 https://github.com/urielha/log4stash 使其完整支持 .Net Standard

项目来自 [urielha/log4stash](https://github.com/urielha/log4stash)

配置方式同原项目配置