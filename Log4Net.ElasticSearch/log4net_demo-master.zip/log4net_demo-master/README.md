# log4net_demo
.net core 使用 log4net

## console中使用 

version 1.0 : 简单测试和使用

vwesion 2.0 : 封装log4net